#pragma once

#include <iostream>
#include <vector>

namespace hw0
{

class Graph
{
public:
  Graph( uint32_t num_nodes )
    : neighbors_for_nodes( num_nodes ) /* Constructs neighbors_for_nodes with `num_nodes` size */
  {
    /* The constructor of the `Graph` class. */
  }

  ~Graph()
  {
    /* The destructor of the `Graph` class. */
  }

  void add_edge( uint32_t from, uint32_t to )
  {
    /* TODO: Add a new edge in your data structure. You can remove the following line. */
    std::cout << "[i] add edge from " << from << " to " << to << std::endl;
  }

  uint32_t num_degree_k( uint32_t k ) const
  {
    /* TODO: Count the number of nodes with degree `k`. */
    return 0;
  }

private:
  /* Possible data structure: each node (index) as a vector of neighbors */
  std::vector<std::vector<uint32_t>> neighbors_for_nodes;
};

} // namespace hw0